
/**
 * This driver class will output the data onto the screen
 * 
 * @author Son Huynh
 * @version 4/16/2014
 */

public class Driver
{
   public static void main(String [ ] args)
   { 
       double [ ] testArray = {3, 6, 2, 5, 8, 4, 1, 7};                                     //Declaring variables
       double [ ] results;
       ArrayFunctions af = new ArrayFunctions( );
       System.out.println("This is the original array: ");
       af.printMe(testArray);                                                               //Prints the original array
       
       System.out.println("\nThis is a test of the sortMe( ) method and the printMe( ) methods. ");
       results = af.sortMe(testArray);                                                      //Sends the original array to sortMe method
       af.printMe(results);                                                                 //Prints the sorted array
       
       System.out.println();
       System.out.println("\nThis is a test of getMax( )");
       System.out.println("The maximum value in the array is: " +af.getMax(testArray));     //Prints the max value in the aray
       
       System.out.println("\nThis is a test of getMin( )");
       System.out.println("The minimum value in the array is: " + af.getMin(testArray));    //Prints the min value in the array
       
       System.out.println("\nThis is a test of sumMeUp( )");
       System.out.println("The sum of the values in the array is: " +af.sumMeUp(testArray));    //Prints the sum of the values in the array
       
       System.out.println("\nThis is a test of reverseMe( )");
       results = af.reverseMe(testArray);                                                   //Sends the array to reverseMe method
       af.printMe(results);                                                                 //Prints the reversed array
       
       System.out.println();
       System.out.println("\nThis is a test of whereAmI( )");                               
       System.out.println("The value 8 is at subscript " + af.whereAmI(testArray, 8));      //Prints the subscript of the value 8, which is within the array
       
       System.out.println("\nThis is a test of doubleMySize(  )");
       testArray = af.doubleMySize(testArray);                                              //Sends the array to doubleMySize method
       af.printMe(testArray);                                                               //Prints the doubled array
       
       System.out.println();
       System.out.println("\nEnd of tests");
       
   }
       
}

/**
 * This class implements the ArrayFunctionsInterface and manipulate arrays
 * 
 * @author Son Huynh
 * @version 4/16/2014
 */
public class ArrayFunctions implements ArrayFunctionsInterface
{    
    /**
     * ArrayFunctions
     * This is the default constructor
     * 
     * @param none
     * @return none
     */     
    public ArrayFunctions()
    {
        
    }
    
    /**
     * sortMe
     * This method sorts the array in ascending order
     * 
     * @param array represents the array inputted
     * @return the sorted array
     */    
    public double [ ] sortMe(double [ ] array)
    {
        double temp;                                        //Declaring variable
        double [] sortedArray = new double[array.length];   //Creating a new array to be sorted
        
        for (int x = 0; x < array.length; x++)
        {
            sortedArray[x] = array[x];                      //Copying the content of the original array
        }
        
        for (int x = 1; x < sortedArray.length; x++)              //Performing a bubble sort
        {
            for (int y = 0; y < sortedArray.length - 1; y++)
            {
                if (sortedArray[y] > sortedArray[y+1])            //If a number is bigger than the number after
                {
                    temp = sortedArray[y];                        //Assign the first number to temp
                    sortedArray[y] = sortedArray[y+1];            //Assign the smaller number to the first slot
                    sortedArray[y+1] = temp;                      //Assign the larger number, held by temp, to the second slot
                }
            }
        }        

        return sortedArray;
    }
    
    /**
     * getMax
     * This method finds the maximum value in the array
     * 
     * @param array represents the array inputted
     * @return the maximum value
     */        
    public double getMax(double [ ] array)
    {
        double max = array[0];                              //Declaring variable
        
        for (int x = 0; x < array.length; x++)
        {
            if (array[x] > max)                             //If a number is bigger than the max
                max = array[x];                             //Assign that number to become the new max
        }
        
        return max;
    }
        
    /**
     * getMin
     * This method finds the minimum value in the array
     * 
     * @param array represents the array inputted
     * @return the minimum value
     */        
    public double getMin(double [ ]  array)
    {
        double min = array[0];                              //Declaring variable
        
        for (int x = 0; x < array.length; x++)
        {
            if (array[x] < min)                             //If a number is less than the min
                min = array[x];                             //Assign that number to become the new min
        }
        
        return min;        
    }
    
    /**
     * whereAmI
     * This method the index of the number inputted
     * 
     * @param array represents the array inputted, searchValue represents the number the user wants to know the index of
     * @return the index of the desired element
     */        
    public int whereAmI(double [ ] array, double  searchValue)
    {
        int index = 0;                                      //Declaring variable
        
        for (int x = 0; x < array.length; x++)
        {
            if (searchValue == array[x])                    //If an element matches the search value
                index = x;                                  //Assigns the index of that element into variable "index"
        }
        
        return index;
    }
    
    /**
     * sumMeUp
     * This method calculates the sum of all the elements inside the array
     * 
     * @param array represents the array inputted
     * @return the sum
     */        
    public double sumMeUp(double [ ] array)
    {
        double sum = 0;                                     //Declaring variable
        
        for (int x = 0; x < array.length; x++)
        {
            sum += array[x];                                //Adding up the elements in the array
        }
        
        return sum;
    }
    
    /**
     * reverseMe
     * This method reverses the array
     * 
     * @param array represents the array inputted
     * @return the reversed array
     */        
    public double [ ] reverseMe(double [ ] array)
    {
        double [] reversedArray = new double[array.length]; //Creating a new array with equal length 
        int y = 0;
        
        for (int x = array.length - 1; x >= 0; x--)
        {
            reversedArray[y] = array[x];                    //Assigning the last element of the 1st array to the first element of the second array
            y++;                                            //Incrementing y by 1
        }
        
        return reversedArray;
    }
        
    /**
     * printMe
     * This method prints the array
     * 
     * @param array represents the array inputted
     * @return void
     */        
    public void printMe(double [ ] array)
    {
        for (int x = 0; x < array.length; x++)
        {
            System.out.print(array[x] + "  ");              //Outputting the array
        }
    }
    
    /**
     * doubleMySize
     * This method doubles the size of the array
     * 
     * @param array represents the array inputted
     * @return the doubled array
     */        
    public double[ ] doubleMySize(double [ ] array)
    {
        double [] doubledArray = new double[array.length * 2];  //Creating a new array with double the original size
        
        for (int x = 0; x < array.length; x++)
        {
            doubledArray[x] = array[x];                     //Assigning values from the original array to the new array
        }        
        
        return doubledArray;
    }
}

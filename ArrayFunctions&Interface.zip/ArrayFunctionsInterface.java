/**
 * This interface specifies several
 * methods for operations on an array of double
 * (or int) values.
 * 
 * @author Son Huynh
 * @version 4/16/2014
 */

public interface ArrayFunctionsInterface
{
	public double [ ] sortMe(double [ ] array);
	public double  getMax(double [ ] array);
 	public double  getMin(double [ ]  array);
    public int whereAmI(double [ ] array, double  searchValue);
    public double sumMeUp(double [ ] array);
	public double [ ] reverseMe(double [ ] array);
    public void printMe(double [ ] array);
    public double[ ] doubleMySize(double [ ] array);
}
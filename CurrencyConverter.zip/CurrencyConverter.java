
/**
 * This class converts currency from one type to another
 * 
 * @author Son Huynh
 * @version 1/26/2014
 */

public class CurrencyConverter
{
    // declaring constants

    private static final double DOLLAR = 1;
    private static final double EUROS = .7310;
    private static final double POUNDS = .6048;
    private static final double YEN = 102.47;
    
    // declaring fields
    
    private double dollarAmount;
    private double eurosAmount;
    private double poundsAmount;
    private double yenAmount;
    
    // Default constructor, used to give starting values
    public CurrencyConverter( )
    {
        dollarAmount = 1;
        eurosAmount = .7310;
        poundsAmount = .6048;
        yenAmount = 102.47;
    }
    
    /**
     * CurrencyConverter
     * This constructor expects 2 values, conversion takes place here.
     * 
     * @param inAmount represents the input currency amount. type represents the currency type
     * @return void
     */    
    
    public CurrencyConverter(double inAmount, char type)
    {
        if (type == 'D' || type == 'd')                 //If they indicate dollar
        {
            dollarAmount = inAmount;                    //Assigning the amount into dollarAmount
            eurosAmount = inAmount * EUROS;             //Converting from dollar to euro
            poundsAmount = inAmount * POUNDS;           //Converting from dollar to pound
            yenAmount = inAmount * YEN;                 //Converting from dollar to yen
        }
        
        if (type == 'E' || type == 'e')                 //If they indicate euro
        {
            eurosAmount = inAmount;                     //Assigning the amount into eurosAmount
            dollarAmount = inAmount / EUROS;            //Converting from euro to dollar
            poundsAmount = inAmount / EUROS * POUNDS;   //Converting from euro to pound
            yenAmount = inAmount / EUROS * YEN;         //Converting from euro to yen
        }
        
        if (type == 'P' || type == 'p')                 //If they indicate pound
        {       
            poundsAmount = inAmount;                    //Assigning the amount into poundsAmount
            dollarAmount = inAmount / POUNDS;           //Converting from pound to dollar
            eurosAmount = inAmount / POUNDS * EUROS;    //Converting from pound to euro
            yenAmount = inAmount / POUNDS * YEN;        //Converting from pound to yen
        }
        
        if (type == 'Y' || type == 'y')                 //If they indicate yen
        {
            yenAmount = inAmount;                       //Assigning the amount into yenAmount
            dollarAmount = inAmount / YEN;              //Converting from yen to dollar
            eurosAmount = inAmount / YEN * EUROS;       //Converting from yen to euro
            poundsAmount = inAmount / YEN * POUNDS;     //Converting from yen to pound
        }
    }
    
    
    /**
     * setCurrency
     * This method allows the user to change the currency amount and type
     * and still maintains the consistency of all the fields.
     * 
     * @param inAmount represents the input currency amount. type represents the currency type
     * @return void
     */    
    
    public void setCurrency(double inAmount, char type)
    {
        if (type == 'D' || type == 'd')                 //If they indicate dollar
        {
            dollarAmount = inAmount;                    //Assigning the amount into dollarAmount
            eurosAmount = inAmount * EUROS;             //Converting from dollar to euro
            poundsAmount = inAmount * POUNDS;           //Converting from dollar to pound
            yenAmount = inAmount * YEN;                 //Converting from dollar to yen
        }
        
        if (type == 'E' || type == 'e')                 //If they indicate euro
        {
            eurosAmount = inAmount;                     //Assigning the amount into eurosAmount
            dollarAmount = inAmount / EUROS;            //Converting from euro to dollar
            poundsAmount = inAmount / EUROS * POUNDS;   //Converting from euro to pound
            yenAmount = inAmount / EUROS * YEN;         //Converting from euro to yen
        }
        
        if (type == 'P' || type == 'p')                 //If they indicate pound
        {       
            poundsAmount = inAmount;                    //Assigning the amount into poundsAmount
            dollarAmount = inAmount / POUNDS;           //Converting from pound to dollar
            eurosAmount = inAmount / POUNDS * EUROS;    //Converting from pound to euro
            yenAmount = inAmount / POUNDS * YEN;        //Converting from pound to yen
        }
        
        if (type == 'Y' || type == 'y')                 //If they indicate yen
        {
            yenAmount = inAmount;                       //Assigning the amount into yenAmount
            dollarAmount = inAmount / YEN;              //Converting from yen to dollar
            eurosAmount = inAmount / YEN * EUROS;       //Converting from yen to euro
            poundsAmount = inAmount / YEN * POUNDS;     //Converting from yen to pound
        }
    }
    
    /**
     * getDollar
     * This method returns the dollarAmount
     * 
     * @param none
     * @return dollarAmount
     */      
    
    public double getDollar()
    {
        return dollarAmount;                            //Returns the dollarAmount
    }
    
    /**
     * getEuros
     * This method returns the eurosAmount
     * 
     * @param none
     * @return eurosAmount
     */    
    
    public double getEuros()
    {
        return eurosAmount;                             //Returns the eurosAmount
    }
    
    /**
     * getPounds
     * This method returns the poundsAmount
     * 
     * @param none
     * @return poundsAmount
     */    
    
    public double getPounds()
    {
        return poundsAmount;                            //Returns the poundsAmount
    }
    
    /**
     * getYen
     * This method returns the yenAmount
     * 
     * @param none
     * @return yenAmount
     */    
    
    public double getYen()
    {
        return yenAmount;                               //Returns the yenAmount
    }    
            
}

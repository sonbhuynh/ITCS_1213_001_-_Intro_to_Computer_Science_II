
/**
 * This class is the main execution of this Java project. It creates reference variable and
 * outputs all of the amount in all 4 scales.
 * 
 * @author Son Huynh
 * @version 1/27/2014
 */

import javax.swing.JOptionPane;

public class Driver
{
    public static void main(String [ ] args)
    {
        CurrencyConverter cc;               //Creates a reference variable
        cc = new CurrencyConverter( );      //Creates an object using the CurrencyConverter class
        
        System.out.println("The dollar amount is " + cc.getDollar());       //Outputs dollar amount
        System.out.println("The euros amount is " + cc.getEuros());         //Outputs euros amount
        System.out.println("The pounds amount is " + cc.getPounds());       //Outputs pounds amount
        System.out.println("The yen amount is " + cc.getYen());             //Outputs yen amount
        System.out.println();
        
        //Testing setMethod by sending in parameters
        cc.setCurrency(4, 'D');                                             //Calling mutator method to change value
        
        System.out.println("The dollar amount is " + cc.getDollar());       //Outputs dollar amount
        System.out.println("The euros amount is " + cc.getEuros());         //Outputs euros amount
        System.out.println("The pounds amount is " + cc.getPounds());       //Outputs pounds amount
        System.out.println("The yen amount is " + cc.getYen());             //Outputs yen amount   
        System.out.println();        
        
        //Testing setMethod by sending in parameters
        cc.setCurrency(6, 'E');                                             //Calling mutator method to change value
        
        System.out.println("The dollar amount is " + cc.getDollar());       //Outputs dollar amount
        System.out.println("The euros amount is " + cc.getEuros());         //Outputs euros amount
        System.out.println("The pounds amount is " + cc.getPounds());       //Outputs pounds amount
        System.out.println("The yen amount is " + cc.getYen());             //Outputs yen amount   
        System.out.println();           
        
        //Testing setMethod by sending in parameters
        cc.setCurrency(10, 'P');                                            //Calling mutator method to change value
        
        System.out.println("The dollar amount is " + cc.getDollar());       //Outputs dollar amount
        System.out.println("The euros amount is " + cc.getEuros());         //Outputs euros amount
        System.out.println("The pounds amount is " + cc.getPounds());       //Outputs pounds amount
        System.out.println("The yen amount is " + cc.getYen());             //Outputs yen amount   
        System.out.println();    
        
        //Testing setMethod by sending in parameters
        cc.setCurrency(200, 'Y');                                           //Calling mutator method to change value
        
        System.out.println("The dollar amount is " + cc.getDollar());       //Outputs dollar amount
        System.out.println("The euros amount is " + cc.getEuros());         //Outputs euros amount
        System.out.println("The pounds amount is " + cc.getPounds());       //Outputs pounds amount
        System.out.println("The yen amount is " + cc.getYen());             //Outputs yen amount   
        System.out.println();            
        
    }
}


/**
 * This class will convert numbers to their corresponding words.
 * 
 * @author Son Huynh 
 * @version 3/5/2014
 */
public class Converter
{
    // Declaring fields
    private String original;
    private StringBuilder workingOnIt;
    private String converted;

    public Converter(String inString)
    {
        //Creating String objects
        original = new String(inString);                    
        workingOnIt = new StringBuilder(inString);
    }
    
    /**
     * convert
     * This method converts the original string into a new string
     * 
     * @param inString represents the string input by the user
     * @return none
     */    

    public void convert(String inString)
    {
        //This if statement sees if the first character is a number, and the second is not a number, then it knows that the first character is a single digit number
        if ((Character.isDigit(workingOnIt.charAt(1)) == false) && (Character.isDigit(workingOnIt.charAt(0)) == true))
        {
            if(workingOnIt.charAt(0) == '0')                        //If the character is 0, change it to Zero
                workingOnIt.replace(0,1,"Zero");        
            if(workingOnIt.charAt(0) == '1')                        //If the character is 1, change it to One
                workingOnIt.replace(0,1,"One");
            if(workingOnIt.charAt(0) == '2')                        //If the character is 2, change it to Two
                workingOnIt.replace(0,1,"Two");
            if(workingOnIt.charAt(0) == '3')                        //If the character is 3, change it to Three
                workingOnIt.replace(0,1,"Three");
            if(workingOnIt.charAt(0) == '4')                        //If the character is 4, change it to Four
                workingOnIt.replace(0,1,"Four");
            if(workingOnIt.charAt(0) == '5')                        //If the character is 5, change it to Five
                workingOnIt.replace(0,1,"Five");
            if(workingOnIt.charAt(0) == '6')                        //If the character is 6, change it to Six
                workingOnIt.replace(0,1,"Six");            
            if(workingOnIt.charAt(0) == '7')                        //If the character is 7, change it to Seven
                workingOnIt.replace(0,1,"Seven");
            if(workingOnIt.charAt(0) == '8')                        //If the character is 8, change it to Eight
                workingOnIt.replace(0,1,"Eight");
            if(workingOnIt.charAt(0) == '9')                        //If the character is 9, change it to Nine
                workingOnIt.replace(0,1,"Nine");
        }
        
        
        //This for loop checks each character and the character before and after it. If either is a non-number, then the character is a single digit
        for (int index = 2; index < original.length() - 1; index++)
        {
            if ((Character.isDigit(workingOnIt.charAt(index-1)) == false) && (Character.isDigit(workingOnIt.charAt(index+1)) == false))
            {
                if(workingOnIt.charAt(index) == '0')                        //If the character is 0, change it to zero
                    workingOnIt.replace(index,index+1,"zero");
                if(workingOnIt.charAt(index) == '1')                        //If the character is 1, change it to one
                    workingOnIt.replace(index,index+1,"one");
                if(workingOnIt.charAt(index) == '2')                        //If the character is 2, change it to two
                    workingOnIt.replace(index,index+1,"two");
                if(workingOnIt.charAt(index) == '3')                        //If the character is 3, change it to three
                    workingOnIt.replace(index,index+1,"three");
                if(workingOnIt.charAt(index) == '4')                        //If the character is 4, change it to four
                    workingOnIt.replace(index,index+1,"four");
                if(workingOnIt.charAt(index) == '5')                        //If the character is 5, change it to five
                    workingOnIt.replace(index,index+1,"five");  
                if(workingOnIt.charAt(index) == '6')                        //If the character is 6, change it to six
                    workingOnIt.replace(index,index+1,"six");
                if(workingOnIt.charAt(index) == '7')                        //If the character is 7, change it to seven
                    workingOnIt.replace(index,index+1,"seven");
                if(workingOnIt.charAt(index) == '8')                        //If the character is 8, change it to eight
                    workingOnIt.replace(index,index+1,"eight");
                if(workingOnIt.charAt(index) == '9')                        //If the character is 9, change it to nine
                    workingOnIt.replace(index,index+1,"nine");
            }
        }
        
        //This if statement checks the very last letter to see if it's a number and the character before that a non-number. If that is true, then the last character is a single digit
        if ((Character.isDigit(workingOnIt.charAt(workingOnIt.length()-2)) == false) && (Character.isDigit(workingOnIt.charAt(workingOnIt.length()-1)) == true))
        {
            if(workingOnIt.charAt(workingOnIt.length()-1) == '0')                        //If the character is 0, change it to zero
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"zero");
            if(workingOnIt.charAt(workingOnIt.length()-1) == '1')                        //If the character is 1, change it to one
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"one");
            if(workingOnIt.charAt(workingOnIt.length()-1) == '2')                        //If the character is 2, change it to two
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"two");
            if(workingOnIt.charAt(workingOnIt.length()-1) == '3')                        //If the character is 3, change it to three
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"three");
            if(workingOnIt.charAt(workingOnIt.length()-1) == '4')                        //If the character is 4, change it to four
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"four");
            if(workingOnIt.charAt(workingOnIt.length()-1) == '5')                        //If the character is 5, change it to five
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"five");  
            if(workingOnIt.charAt(workingOnIt.length()-1) == '6')                        //If the character is 6, change it to six
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"six");
            if(workingOnIt.charAt(workingOnIt.length()-1) == '7')                        //If the character is 7, change it to seven
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"seven");
            if(workingOnIt.charAt(workingOnIt.length()-1) == '8')                        //If the character is 8, change it to eight
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"eight");
            if(workingOnIt.charAt(workingOnIt.length()-1) == '9')                        //If the character is 9, change it to nine
                workingOnIt.replace(workingOnIt.length()-1,workingOnIt.length(),"nine");    
        }
        converted = new String(workingOnIt);                                            //Creates a String object with the new converted string
    }
    
    
    /**
     * getConverted
     * This method returns the converted string
     * 
     * @param none
     * @return The converted string
     */
    
    public String getConverted()
    {
        return converted;                                                               //Returns converted
    }
    
}

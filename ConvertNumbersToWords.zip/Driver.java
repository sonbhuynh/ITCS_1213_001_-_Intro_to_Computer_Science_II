
/**
 * This class allows the user to input the location of the input and output file
 * 
 * @author Son Huynh
 * @version 3/5/2014
 */

import java.util.*;
import java.io.*;

public class Driver
{
    public static void main(String[] args) throws IOException
    {
        Scanner input;
        input = new Scanner(System.in);                         //Creating Scanner object for input
        Scanner inputFile;
        
        String inFilename;                                      //Creating variables
        String outFilename;
        String original;
        String workingOnIt;
        
        Converter test;                                         //Creating a reference variable
        
        System.out.println("Enter the location of the input file: ");   //Input file
        inFilename = input.nextLine();
        
        System.out.println("Enter the location of the output file: ");  //Input file
        outFilename = input.nextLine();        
        
        inputFile = new Scanner(new File(inFilename));                  //Creating a Scanner object for inputFile
        PrintWriter outputFile = new PrintWriter(outFilename);          //Creating a PrintWriter object for outputFile
        
        while (inputFile.hasNext())
        {
            original = inputFile.nextLine();                      //Reading in the whole sentence
            workingOnIt = new String(original);                   //Creating workingOnIt string out of the original
            
            test = new Converter(workingOnIt);                    //Creating a Converter object
            test.convert(workingOnIt);                            //Calling the convert method
            
            System.out.println(test.getConverted());              //Outputting the sentences to the screen
            outputFile.println(test.getConverted());              //Outputting the sentences to the file
        }
        inputFile.close();                                        //Closing the input file
        outputFile.close();                                       //Closing the output file
    }
}

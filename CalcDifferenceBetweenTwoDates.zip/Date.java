
/**
 * This class adds, subtracts, and calculates the difference between two dates.
 * 
 * @author Son Huynh
 * @version 4/4/2014
 */

import java.util.*;

public class Date
{
    // Declaring fields
    private int month;
    private int day;
    private int year;
    
    public Date()
    {
        //Initializing variables to 0
        month = 0;
        day = 0;
        year = 0;
    }
    
    
    /**
     * Date
     * This constructor expects 4 values; assigning values takes place here
     * 
     * @param inMonth represents the month input by the user, inDay represents the day input by the user,
     * and inYear represents the year input by the user
     * @return none
     */       
    public Date(int inMonth, int inDay, int inYear)
    {
        month = inMonth;
        day = inDay;
        year = inYear;
    }
    
    
    /**
     * Date
     * This is a copy constructor; it expects 1 value and cloning takes place here
     * 
     * @param inDate represents the Date object input by the user
     * @return none
     */     
    public Date(Date inDate)
    {
        month = inDate.month;
        day = inDate.day;
        year = inDate.year;
    }
    
    
    /**
     * toString
     * This method displays a textual representation of a Date object
     * 
     * @param none
     * @return a string that represents the Date object
     */     
    public String toString()
    {
        return month + "/" + day + "/" + year;
    }
    
    
    /**
     * equals
     * This method compares two dates to see if their years are equal
     * 
     * @param inDate represents the Date object input by the user
     * @return a boolean, true or false, depending on the years of the two Date objects
     */     
    public boolean equals(Date inDate)
    {
        return this.year == inDate.year;
    }
    
    
    /**
     * compareTo
     * This method compares two Date objects and see which one has the greater year
     * 
     * @param inDate represents the Date object input by the user
     * @return result
     */     
    public int compareTo(Date inDate)
    {
        int result;
        
        if (this.year > inDate.year)
            result = 1;
        else if (this.year < inDate.year)
            result = -1;
        else
            result = 0;
            
        return result;
    }

    
    /**
     * add
     * This constructor expects 1 value; it adds the day input by the user and creates a new Date object
     * 
     * @param numDay represents the number of days being added
     * @return a new Date object
     */     
    public Date add(int numDay)
    {
        return new Date(month, day + numDay, year);
    }
    
    
    /**
     * subtract
     * This constructor expects 1 value; it subtracts the day input by the user and creates a new Date object
     * 
     * @param numDay represents the number of days being subtracted
     * @return a new Date object
     */     
    public Date subtract(int numDay)
    {
        return new Date(month, day - numDay, year);
    }
    
    
    /**
     * adjustAdd
     * This method adjusts the date being returned if the day exceeds the max number of day
     * for the corresponding month, taken leap year into account
     * 
     * @param none
     * @return a new Date object
     */     
    public Date adjustAdd()
    {
        int remDay = 0;                             //Declaring int variable
        
        switch(month)
        {
            case 1:
                if (day > 31)                       //If the day exceeds 31
                {
                    remDay = day - 31;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
            case 2:
                if (day > 28)                       //If the day exceeds 28
                {
                    if ((year % 4 == 0) && (year % 100 == 0 && year % 400 == 0))        //If it's a leap year
                    {
                        if (day > 29)                                                   //If the day exceeds 29
                        {
                            remDay = day - 29;                                          //Calculating remainder day
                            month++;                                                    //Increases month by 1 (going to next month)
                        }
                    }
                    else if((year % 4 == 0) && (year % 100 != 0))                       //If it's a leap year
                    {
                        if (day > 29)                                                   //If the day exceeds 29
                        {
                            remDay = day - 29;                                          //Calculating remainder day
                            month++;                                                    //Increases month by 1 (going to next month)
                        }
                    }                
                    else
                    {
                        if (day > 28)                       //If the day exceeds 28
                        {
                            remDay = day - 28;              //Calculating remainder day
                            month++;                        //Increases month by 1 (going to next month)
                        }
                    }  
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
            case 3:
                if (day > 31)                       //If the day exceeds 31
                {
                    remDay = day - 31;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
            case 4:
                if (day > 30)                       //If the day exceeds 30
                {
                    remDay = day - 30;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }
                break;
            case 5:
                if (day > 31)                       //If the day exceeds 31
                {
                    remDay = day - 31;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
            case 6:
                if (day > 30)                       //If the day exceeds 30
                {
                    remDay = day - 30;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;  
            case 7:
                if (day > 31)                       //If the day exceeds 31
                {
                    remDay = day - 31;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;                
            case 8:
                if (day > 31)                       //If the day exceeds 31
                {
                    remDay = day - 31;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
            case 9:
                if (day > 30)                       //If the day exceeds 30
                {
                    remDay = day - 30;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }   
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
            case 10:
                if (day > 31)                       //If the day exceeds 31
                {
                    remDay = day - 31;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }     
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
            case 11:
                if (day > 30)                       //If the day exceeds 30
                {
                    remDay = day - 30;              //Calculating remainder day
                    month++;                        //Increases month by 1 (going to next month)
                }
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
            case 12:
                if (day > 31)                       //If the day exceeds 31
                {
                    remDay = day - 31;              //Calculating remainder day
                    month = 1;                      //Resetting month back to 1 (January)
                    year++;                         //Increases year by 1 (going to next year)
                }        
                else
                {
                    remDay = day;                   //Assign day as remDay
                }                
                break;
        }
        
        Date adjustedAddedDate = new Date(month, remDay, year); //Creates a new date out of the adjust information
        
        return adjustedAddedDate;
    }

    
    /**
     * adjustSubtract
     * This method adjusts the date being returned if the day goes negative from being subtracted,
     * taken leap year into account
     * 
     * @param none
     * @return a new Date object
     */      
    public Date adjustSubtract()
    {
        int remDay = 0;
        
        switch(month)
        {            
            case 1:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 31 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month = 12;                     //Resetting month to 12 (December)
                    year--;                         //Decreases year by 1 (going to previous year)
                }
                break;
            case 2:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 31 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;
            case 3:
                if ((year % 4 == 0) && (year % 100 == 0 && year % 400 == 0))
                {
                    if (day < 1)
                    {
                        remDay = day;                   //Assigns the negative day as remainder day
                        day = 29 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                        month--;                        //Decreases month by 1
                    }
                }
                else if ((year % 4 == 0) && (year % 100 != 0))
                {
                    if (day < 1)
                    {
                        remDay = day;                   //Assigns the negative day as remainder day
                        day = 29 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                        month--;                        //Decreases month by 1
                    }
                }
                else
                {
                    if (day < 1)
                    {
                        remDay = day;                   //Assigns the negative day as remainder day
                        day = 28 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                        month--;                        //Decreases month by 1
                    }                    
                }
                break;
            case 4:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 31 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;
            case 5:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 30 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;
            case 6:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 31 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;   
            case 7:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 30 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;
            case 8:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 31 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;
            case 9:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 31 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;
            case 10:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 30 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;
            case 11:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 31 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break; 
            case 12:
                if (day < 1)
                {
                    remDay = day;                   //Assigns the negative day as remainder day
                    day = 30 + remDay;              //The new day is equal to the day of the previous month minus the remainder day
                    month--;                        //Decreases month by 1
                }
                break;                
        }
        
        Date adjustedSubtractedDate = new Date(month, day, year);
        
        return adjustedSubtractedDate;
    }
    
    
    /**
     * difference
     * This method calculates the difference between two dates,
     * taken leap year into account
     * 
     * @param inDate represents the second date the user input in order to find the difference
     * @return an int
     */     
    public int difference(Date inDate)
    {
        //Initializating variables
        int numberOfDays = 0;
        int leftOverFirst = 0;
        int leftOverSecond = 0;
        int februaryDay = 0;
        int numberOfYears = 0;
        
        switch (this.month)
        {
            case 1:
                leftOverFirst = 31 - this.day;              //Calculating the days left over from the month of the first date
                break;
            case 2:
                if ((this.year % 4 == 0) && (this.year % 100 == 0 && this.year % 400 == 0))
                {
                    leftOverFirst = 29 - this.day;          //Calculating the days left over from the month of the first date
                }
                else if ((this.year % 4 == 0) && (this.year % 100 != 0))
                {
                    leftOverFirst = 29 - this.day;          //Calculating the days left over from the month of the first date
                }
                else          
                    leftOverFirst = 28 - this.day;          //Calculating the days left over from the month of the first date
                break;
            case 3:
                leftOverFirst = 31 - this.day;              //Calculating the days left over from the month of the first date
                break;
            case 4:
                leftOverFirst = 30 - this.day;              //Calculating the days left over from the month of the first date
                break;  
            case 5:
                leftOverFirst = 31 - this.day;              //Calculating the days left over from the month of the first date
                break;
            case 6:
                leftOverFirst = 30 - this.day;              //Calculating the days left over from the month of the first date
                break;                
            case 7:
                leftOverFirst = 31 - this.day;              //Calculating the days left over from the month of the first date
                break;
            case 8:
                leftOverFirst = 31 - this.day;              //Calculating the days left over from the month of the first date
                break;
            case 9:
                leftOverFirst = 30 - this.day;              //Calculating the days left over from the month of the first date
                break;            
            case 10:
                leftOverFirst = 31 - this.day;              //Calculating the days left over from the month of the first date
                break;
            case 11:
                leftOverFirst = 30 - this.day;              //Calculating the days left over from the month of the first date
                break;
            case 12:
                leftOverFirst = 31 - this.day;              //Calculating the days left over from the month of the first date
                break;                
        }
        
        switch (inDate.month)
        {
            case 1:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;
            case 2:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;
            case 3:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;
            case 4:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;  
            case 5:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;
            case 6:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;                
            case 7:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;
            case 8:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;
            case 9:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;            
            case 10:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;
            case 11:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;
            case 12:
                leftOverSecond = inDate.day;              //Calculating the days left over from the month of the second date
                break;                
        }        
        
        numberOfYears = inDate.year - this.year;
        
        /***************************Starting month is January***************************/
        if (this.month == 1 && inDate.month == 2)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;          //Calculating the difference between January and February
        }
        else if (this.month == 1 && inDate.month == 3)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + numberOfYears * 365;                //Calculating the difference between January and March
        }
        else if (this.month == 1 && inDate.month == 4)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 + numberOfYears * 365;          //Calculating the difference between January and April
        }
        else if (this.month == 1 && inDate.month == 5)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 * 1 + 30 * 1 + numberOfYears * 365;          //Calculating the difference between January and May
        }
        else if (this.month == 1 && inDate.month == 6)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 * 2 + 30 * 1 + numberOfYears * 365;          //Calculating the difference between January and June
        }
        else if (this.month == 1 && inDate.month == 7)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 * 2 + 30 * 2 + numberOfYears * 365;          //Calculating the difference between January and July
        }
        else if (this.month == 1 && inDate.month == 8)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 * 3 + 30 * 2 + numberOfYears * 365;          //Calculating the difference between January and August
        }
        else if (this.month == 1 && inDate.month == 9)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 * 4 + 30 * 2 + numberOfYears * 365;          //Calculating the difference between January and September
        }
        else if (this.month == 1 && inDate.month == 10)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 * 4 + 30 * 3 + numberOfYears * 365;          //Calculating the difference between January and October
        }
        else if (this.month == 1 && inDate.month == 11)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 * 5 + 30 * 3 + numberOfYears * 365;          //Calculating the difference between January and November
        }
        else if (this.month == 1 && inDate.month == 12)
        {
            if ((inDate.year % 4 == 0) && (inDate.year % 100 == 0 && inDate.year % 400 == 0))
            {
                februaryDay = 29;
            }
            else if ((inDate.year % 4 == 0) && (inDate.year % 100 != 0))
            {
                februaryDay = 29;
            }
            else              
                februaryDay = 28;
            
            numberOfDays = leftOverFirst + leftOverSecond + februaryDay + 31 * 5 + 30 * 4 + numberOfYears * 365;          //Calculating the difference between January and December
        }          
        /*******************************************************************************/ 
        
        
        /***************************Starting month is February***************************/        
        if (this.month == 2 && inDate.month == 3)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between February and March
        }
        else if (this.month == 2 && inDate.month == 4)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 + numberOfYears * 365;                 //Calculating the difference between February and April
        }   
        else if (this.month == 2 && inDate.month == 5)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between February and May
        }         
        else if (this.month == 2 && inDate.month == 6)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between February and June
        }
        else if (this.month == 2 && inDate.month == 7)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between February and July
        }
        else if (this.month == 2 && inDate.month == 8)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between February and August
        }        
        else if (this.month == 2 && inDate.month == 9)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 4 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between February and September
        }
        else if (this.month == 2 && inDate.month == 10)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 4 + 30 * 3 + numberOfYears * 365;    //Calculating the difference between February and October
        }
        else if (this.month == 2 && inDate.month == 11)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 5 + 30 * 3 + numberOfYears * 365;    //Calculating the difference between February and November
        }
        else if (this.month == 2 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 5 + 30 * 4 + numberOfYears * 365;    //Calculating the difference between February and December
        }
        /********************************************************************************/
        
        
        /***************************Starting month is March***************************/ 
        if (this.month == 3 && inDate.month == 4)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between March and April
        }
        else if (this.month == 3 && inDate.month == 5)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 30 + numberOfYears * 365;                 //Calculating the difference between March and May
        }
        else if (this.month == 3 && inDate.month == 6)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between March and June
        }
        else if (this.month == 3 && inDate.month == 7)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between March and July
        }
        else if (this.month == 3 && inDate.month == 8)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between March and August
        }
        else if (this.month == 3 && inDate.month == 9)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between March and September
        }
        else if (this.month == 3 && inDate.month == 10)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 3 + numberOfYears * 365;    //Calculating the difference between March and October
        }
        else if (this.month == 3 && inDate.month == 11)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 4 + 30 * 3 + numberOfYears * 365;    //Calculating the difference between March and November
        }
        else if (this.month == 3 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 4 + 30 * 4 + numberOfYears * 365;    //Calculating the difference between March and December
        }
        /*****************************************************************************/
        
        
        /***************************Starting month is April***************************/
        if (this.month == 4 && inDate.month == 5)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between April and May
        }
        else if (this.month == 4 && inDate.month == 6)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 + numberOfYears * 365;                 //Calculating the difference between April and June
        }
        else if (this.month == 4 && inDate.month == 7)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between April and July
        }
        else if (this.month == 4 && inDate.month == 8)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between April and August
        }
        else if (this.month == 4 && inDate.month == 9)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between April and September
        }
        else if (this.month == 4 && inDate.month == 10)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between April and October
        }
        else if (this.month == 4 && inDate.month == 11)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 4 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between April and November
        }
        else if (this.month == 4 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 4 + 30 * 3 + numberOfYears * 365;    //Calculating the difference between April and December
        }
        /*****************************************************************************/
        
        /***************************Starting month is May***************************/
        if (this.month == 5 && inDate.month == 6)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between May and June
        }
        else if (this.month == 5 && inDate.month == 7)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 30 + numberOfYears * 365;                 //Calculating the difference between May and July
        }
        else if (this.month == 5 && inDate.month == 8)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between May and August
        }
        else if (this.month == 5 && inDate.month == 9)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between May and September
        }
        else if (this.month == 5 && inDate.month == 10)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between May and October
        }
        else if (this.month == 5 && inDate.month == 11)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between May and November
        }
        else if (this.month == 5 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 3 + numberOfYears * 365;    //Calculating the difference between May and December
        }
        /***************************************************************************/
        
        /***************************Starting month is June***************************/
        if (this.month == 6 && inDate.month == 7)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between June and July
        }        
        else if (this.month == 6 && inDate.month == 8)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 + numberOfYears * 365;                 //Calculating the difference between June and August
        }
        else if (this.month == 6 && inDate.month == 9)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 0 + numberOfYears * 365;    //Calculating the difference between June and September
        }
        else if (this.month == 6 && inDate.month == 10)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between June and October
        }
        else if (this.month == 6 && inDate.month == 11)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between June and November
        }
        else if (this.month == 6 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 3 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between June and December
        }
        /****************************************************************************/
        
        
        /***************************Starting month is July***************************/
        if (this.month == 7 && inDate.month == 8)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between July and August
        }
        else if (this.month == 7 && inDate.month == 9)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 + numberOfYears * 365;                 //Calculating the difference between June and September
        }
        else if (this.month == 7 && inDate.month == 10)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between June and October
        }
        else if (this.month == 7 && inDate.month == 11)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between June and November
        }
        else if (this.month == 7 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 2 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between June and December
        }
        /****************************************************************************/
        
        
        /***************************Starting month is August***************************/
        if (this.month == 8 && inDate.month == 9)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between August and September
        }
        else if (this.month == 8 && inDate.month == 10)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 30 + numberOfYears * 365;                 //Calculating the difference between August and October
        }
        else if (this.month == 8 && inDate.month == 11)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between August and November
        }
        else if (this.month == 8 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 2 + numberOfYears * 365;    //Calculating the difference between August and December
        }
        /******************************************************************************/
        
        
        /***************************Starting month is September***************************/
        if (this.month == 9 && inDate.month == 10)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between September and October
        }
        else if (this.month == 9 && inDate.month == 11)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 + numberOfYears * 365;                 //Calculating the difference between September and November
        }
        else if (this.month == 9 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 31 * 1 + 30 * 1 + numberOfYears * 365;    //Calculating the difference between September and December
        }
        /*********************************************************************************/
        
        
        /***************************Starting month is October***************************/
        if (this.month == 10 && inDate.month == 11)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between October and November
        }
        else if (this.month == 10 && inDate.month == 12)
        {            
            numberOfDays = leftOverFirst + leftOverSecond + 30 + numberOfYears * 365;                 //Calculating the difference between October and December
        }
        /*******************************************************************************/
        
        
        /***************************Starting month is November***************************/
        if (this.month == 11 && inDate.month == 12)
        {
            numberOfDays = leftOverFirst + leftOverSecond + numberOfYears * 365;                      //Calculating the difference between November and December
        }
        
        
        return numberOfDays;
        
    }
}

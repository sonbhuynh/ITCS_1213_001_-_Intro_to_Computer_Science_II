
/**
 * This is the Driver class, which outputs the main screen to the user
 * 
 * @author Son Huynh
 * @version 4/6/2014
 */
public class Driver
{
    public static void main(String args[])
    {
        Date myDateNormal = new Date(2,15,2014);                //Creating Date objects
        Date myDateLeap = new Date(2,15,2012);
        
        Date myDateDecember = new Date(12,25,2000);
        Date myDateAdd = new Date(4,13,2000);
        
        Date myDateLeapSubtract = new Date(3, 2, 2012);
        Date myDateLeapNormal = new Date(3, 2, 2011);
        
        Date myDateJanuary = new Date(1,5,2000);
        Date myDateSubtract = new Date(12, 6, 2000);
        
        Date myDated1 = new Date(3,20,2000);
        Date myDated2 = new Date(12,25,2000);
        Date myDated3 = new Date(10,13,2002);
        
        System.out.println("Test - Adding 15 days to a normal & leap year date: ");             
        System.out.println("Original date - Normal year: " + myDateNormal);                         //Outputs original normal date before adding 15
        System.out.println("New date - Normal year: " + myDateNormal.add(15).adjustAdd());          //Outputs new normal date after adding 15
        System.out.println();        
        System.out.println("Original date - Leap year: " + myDateLeap);                             //Outputs original leap date before adding 15
        System.out.println("New date - Leap year: " + myDateLeap.add(15).adjustAdd());              //Outputs new leap date after adding 15
        System.out.println();
        System.out.println("_______________________________________________________________");
        System.out.println();        
        

        System.out.println("Test - Adding 10 days to a late December date: ");
        System.out.println("Original date: " + myDateDecember);                                     //Outputs original December date before adding 10
        System.out.println("New date: " + myDateDecember.add(10).adjustAdd());                      //Outputs new December date after adding 10
        System.out.println();
        
        System.out.println("Test - Adding 10 days to a normal date: ");
        System.out.println("Original date: " + myDateAdd);                                          //Outputs original normal date before adding 10
        System.out.println("New date: " + myDateAdd.add(10).adjustAdd());                           //Outputs new normal date after adding 10
        System.out.println();
        System.out.println("_______________________________________________________________");
        System.out.println();
        
        System.out.println("Test - Subtracting 6 days from a normal & leap year date: ");        
        System.out.println("Original date - Normal year: " + myDateLeapNormal);                             //Outputs original normal date before subtract 6
        System.out.println("New date - Normal year: " + myDateLeapNormal.subtract(6).adjustSubtract());     //Outputs new normal date after subtracting 6
        System.out.println();
        System.out.println("Original date - Leap year: " + myDateLeapSubtract);                             //Outputs original leap date before subtract 6
        System.out.println("New date - Leap year: " + myDateLeapSubtract.subtract(6).adjustSubtract());     //Outputs new leap date after subtracting 6
        System.out.println();
        System.out.println("_______________________________________________________________");
        System.out.println();        
        
        System.out.println("Test - Subtracting 10 days from an early January date: ");              
        System.out.println("Original date: " + myDateJanuary);                                              //Outputs original January date before subtracting 10
        System.out.println("New date: " + myDateJanuary.subtract(10).adjustSubtract());                     //Outputs new January date after subtracting 10
        System.out.println();
        
        System.out.println("Test - Subtracting 10 days from a normal date: ");
        System.out.println("Original date: " + myDateSubtract);                                             //Outputs original normal date before subtracting 10
        System.out.println("New date: " + myDateSubtract.subtract(10).adjustSubtract());                    //Outputs new normal date after subtracting 10
        System.out.println();
        System.out.println("_______________________________________________________________");
        System.out.println();        
        
        System.out.println("Test - Difference between two different dates of the same year: ");
        System.out.println("Date 1: " + myDated1);
        System.out.println("Date 2: " + myDated2);
        System.out.println("Result: " + myDated1.difference(myDated2) + " days");
        System.out.println();
        
        System.out.println("Test - Difference between two different dates of different year: ");
        System.out.println("Date 1: " + myDated1);
        System.out.println("Date 2: " + myDated3);
        System.out.println("Result: " + myDated1.difference(myDated3) + " days");        
    }
}

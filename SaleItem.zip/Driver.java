
/**
 * This class is the main execution of this Java project. 
 * 
 * @author Son Huynh
 * @version 2/23/2014
 */

import javax.swing.JOptionPane;
import java.util.Scanner;

public class Driver
{
    public static void main(String [ ] args)
    {
        double inPrice;                     //Declaring variables
        double inDiscount;
        double inTax;
        double inTendered;
        double discountPrice;
        double finalCost;
        double changeDue;
        char goAgain;
        
        SaleItem si;                        //Creates a reference variable
        Scanner input;                      //Creates a reference variable
        
        input = new Scanner(System.in);     //Creates a Scanner object
        
        
        System.out.println("Enter the price of the item: ");                //Input the priceOfItem
        inPrice = input.nextDouble();
        
        System.out.println("Enter the discount rate (in decimal): ");
        inDiscount = input.nextDouble();                                    //Input the discountPercent
        
        System.out.println("Enter the tax rate (in decimal): ");
        inTax = input.nextDouble();                                         //Input the taxRate
        
        System.out.println("Enter the cash tendered: ");                    //Input the cashTendered
        inTendered = input.nextDouble();
        
        si = new SaleItem(inPrice, inDiscount, inTax, inTendered);          //Creates a SaleItem object
        
        discountPrice = si.calcDiscountPrice();                             //Calculating discountPrice
        finalCost = si.calcFinalPrice(discountPrice);                       //Calculating finalCost
        changeDue = inTendered - finalCost;                                 //Calculating changeDue
        
        System.out.println("Your original price is: $" + inPrice);          //Outputs original price
        System.out.println("Your discount price is: $" + discountPrice);    //Outputs discount price
        System.out.println("Your total price is: $" + finalCost);           //Outputs total price
        System.out.println("Your change is: $" + changeDue);                //Outputs changeDue
        
        //****************************************************************
        
        System.out.println("Enter the discount rate (in decimal): ");
        inDiscount = input.nextDouble();                                    //Input the discountPercent
        si.setDiscountPercent(inDiscount);
        
        System.out.println("Enter the cash tendered: ");                    //Input the cashTendered
        inTendered = input.nextDouble();

        discountPrice = si.calcDiscountPrice();                             //Calculating discountPrice
        finalCost = si.calcFinalPrice(discountPrice);                       //Calculating finalCost
        changeDue = inTendered - finalCost;                                 //Calculating changeDue
        
        System.out.println("Your original price is: $" + inPrice);          //Outputs original price
        System.out.println("Your discount price is: $" + discountPrice);    //Outputs discount price
        System.out.println("Your total price is: $" + finalCost);           //Outputs total price
        System.out.println("Your change is: $" + changeDue);                //Outputs changeDue
        
        System.out.println("To repeat, press Y. Otherwise, press any key: ");
        goAgain = input.next().charAt(0);                                   //Input goAgain
        
        if (goAgain == 'Y' || goAgain == 'y')
        {
            do
            {
                System.out.println("Enter the price of the item: ");                //Input the priceOfItem
                inPrice = input.nextDouble();
                si.setPrice(inPrice);
                
                System.out.println("Enter the discount rate (in decimal): ");
                inDiscount = input.nextDouble();                                    //Input the discountPercent
                si.setDiscountPercent(inDiscount);
                
                System.out.println("Enter the cash tendered: ");                    //Input the cashTendered
                inTendered = input.nextDouble();
                
                discountPrice = si.calcDiscountPrice();                             //Calculating discountPrice
                finalCost = si.calcFinalPrice(discountPrice);                       //Calculating finalCost
                changeDue = inTendered - finalCost;                                 //Calculating changeDue
                
                System.out.println();
                System.out.println("Your original price is: $" + inPrice);          //Outputs original price
                System.out.println("Your discount price is: $" + discountPrice);    //Outputs discount price
                System.out.println("Your total price is: $" + finalCost);           //Outputs total price
                System.out.println("Your change is: $" + changeDue);                //Outputs changeDue
                System.out.println();
                
                
                System.out.println("To repeat, press Y. Otherwise, press any key: ");
                goAgain = input.next().charAt(0);                                   //Input goAgain                
            }
            while (goAgain == 'Y' || goAgain == 'y');
        }
        
        if (goAgain != 'Y' || goAgain != 'y')
        {
            System.out.println("Thank you for shopping with us!");                  //Outputs end message
        }
    }
}

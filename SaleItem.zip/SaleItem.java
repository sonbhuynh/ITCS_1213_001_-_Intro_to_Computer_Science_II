
/**
 * This class is used to determine the selling cost of an item that is on sale
 * and display the information along with the change due to the user.
 * 
 * @author Son Huynh
 * @version 2/23/2014
 */
public class SaleItem
{
    // Declaring fields
    
    private double priceOfItem;
    private double discountPercent;
    private double taxRate;
    private double cashTendered;
    
    // Default constructor, used to give starting values
    public SaleItem()
    {
        priceOfItem = 0;                    //Setting priceOfItem to 0
        discountPercent = .1;               //Setting discountPercent to 10%
        taxRate = .075;                     //Setting taxRate to 7.5%
    }
    
    
    /**
     * SaleItem
     * This constructor expects 4 values, assigning values takes place here.
     * 
     * @param inPrice represents item price, inDiscount represents discount percent, inTax represents the tax rate
     * and inTendered represents the amount of cash that was tendered
     * @return void
     */        
    
    public SaleItem(double inPrice, double inDiscount, double inTax, double inTendered)
    {
        priceOfItem = inPrice;              //Setting inPrice to priceOfItem
        discountPercent = inDiscount;       //Assigning inDiscount into discountPercent
        taxRate = inTax;                    //Assigning inTax into taxRate
        cashTendered = inTendered;          //Assigning inTendered into cashTendered
    }
    
    /**
     * setPrice
     * This method allows the user to change the price of the item.
     * 
     * @param inPrice represents the input price amount.
     * @return void
     */     
    
    public void setPrice(double inPrice)
    {
        priceOfItem = inPrice;              //Assigning inPrice into priceOfItem
    }
    
    
    /**
     * setDiscountPercent
     * This method allows the user to change the discount percent.
     * 
     * @param inDiscount represents the input discount percent.
     * @return void
     */
    
    public void setDiscountPercent(double inDiscount)
    {
        discountPercent = inDiscount;       //Assigning inDiscount into discountPercent
    }
    
    
    /**
     * calcDiscountPrice
     * This method calculates the discount price given the original price and discount percent.
     * 
     * @param none.
     * @return discountPrice
     */    
    
    public double calcDiscountPrice()
    {
        double discountPrice;               //Creating a variable
        
        discountPrice = priceOfItem - (priceOfItem * discountPercent);      //Calculating discountPrice
        
        return discountPrice;               //Returns discountPrice
    }
    
    
    /**
     * calcFinalPrice
     * This method calculates the final price with tax applied.
     * 
     * @param discountPrice represents the discount price.
     * @return finalPrice
     */    
    
    public double calcFinalPrice(double discountPrice)
    {
        double finalPrice;                  //Creating a variable
        
        finalPrice = discountPrice + (discountPrice * taxRate);             //Calculating finalPrice
        
        return finalPrice;
    }
}